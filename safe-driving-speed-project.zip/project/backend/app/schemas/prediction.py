from pydantic import BaseModel, Field
from uuid import UUID
from datetime import datetime
from typing import Optional


class PredictionRequest(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    current_speed: float = Field(ge=0, le=300, description="km/h, from device or manual entry")


class PredictionResponse(BaseModel):
    id: UUID
    latitude: float
    longitude: float
    temperature: Optional[float]
    humidity: Optional[float]
    rainfall: Optional[float]
    visibility: Optional[float]
    wind_speed: Optional[float]
    road_condition: Optional[str]
    traffic_density: Optional[str]
    current_speed: Optional[float]
    recommended_speed: float
    risk_level: str
    confidence_score: float
    explanation: str
    shap_values: dict
    created_at: datetime

    class Config:
        from_attributes = True
